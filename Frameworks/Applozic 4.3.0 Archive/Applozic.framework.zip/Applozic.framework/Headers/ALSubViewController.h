//
//  ALSubViewController.h
//  Applozic
//
//  Created by Abhishek Thapliyal on 4/6/17.
//  Copyright © 2017 applozic Inc. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "ALMessagesViewController.h"

@interface ALSubViewController : UIViewController

@property (nonatomic, strong) ALMessagesViewController * msgView;

@end

