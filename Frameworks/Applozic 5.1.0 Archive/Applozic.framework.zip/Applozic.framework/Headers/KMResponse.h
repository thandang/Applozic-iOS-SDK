//
//  KMResponse.h
//  Applozic
//
//  Created by Sunil on 16/02/18.
//  Copyright © 2018 applozic Inc. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "ALJson.h"

@interface KMResponse : ALJson
@property (nonatomic, strong) NSString * code;

@end
