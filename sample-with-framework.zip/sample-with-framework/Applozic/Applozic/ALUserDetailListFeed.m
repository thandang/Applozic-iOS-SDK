//
//  ALUserDetailListFeed.m
//  Applozic
//
//  Created by Abhishek Thapliyal on 10/13/16.
//  Copyright © 2016 applozic Inc. All rights reserved.
//

#import "ALUserDetailListFeed.h"

@implementation ALUserDetailListFeed

-(void)setArray:(NSMutableArray *)array
{
    self.userIdList = [NSMutableArray arrayWithArray:array];
}

@end
