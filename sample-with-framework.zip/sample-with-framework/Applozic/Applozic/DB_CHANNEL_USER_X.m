//
//  DB_CHANNEL_USER_X.m
//  Applozic
//
//  Created by devashish on 28/12/2015.
//  Copyright © 2015 applozic Inc. All rights reserved.
//

#import "DB_CHANNEL_USER_X.h"

@implementation DB_CHANNEL_USER_X

@dynamic channelKey;
@dynamic parentGroupKey;
@dynamic status;
@dynamic userId;
@dynamic unreadCount;

@end
