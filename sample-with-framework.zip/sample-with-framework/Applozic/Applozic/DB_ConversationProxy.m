//
//  DB_ConversationProxy.m
//  Applozic
//
//  Created by devashish on 13/01/2016.
//  Copyright © 2016 applozic Inc. All rights reserved.
//

#import "DB_ConversationProxy.h"

@implementation DB_ConversationProxy

@dynamic iD;
@dynamic created;
@dynamic groupId;
@dynamic topicId;
@dynamic topicDetailJson;
@dynamic closed;
@dynamic userId;

@end
