//
//  ApplozicLoginViewController.h
//  applozicdemo
//
//  Created by Devashish on 08/10/15.
//  Copyright © 2015 applozic Inc. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ApplozicLoginViewController : UIViewController
@end
