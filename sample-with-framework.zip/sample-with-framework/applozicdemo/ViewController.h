//
//  ViewController.h
//  applozicdemo
//
//  Created by Devashish on 07/10/15.
//  Copyright © 2015 applozic Inc. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController


@end

